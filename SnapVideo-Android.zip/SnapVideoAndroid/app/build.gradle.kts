plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.snapvideo.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.snapvideo.app"
        minSdk = 29          // Android 10+: lưu vào Thư viện không cần xin quyền bộ nhớ
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// Cố tình không dùng thư viện ngoài: HttpURLConnection + org.json + MediaStore là đủ.
dependencies { }
