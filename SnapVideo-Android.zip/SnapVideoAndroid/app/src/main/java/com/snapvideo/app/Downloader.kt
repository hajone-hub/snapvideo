package com.snapvideo.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Tải một tệp và lưu thẳng vào Thư viện (Movies/SnapVideo hoặc Pictures/SnapVideo). Android 10+ không cần xin quyền. */
object Downloader {

    fun save(ctx: Context, media: Media, name: String, onProgress: (Int) -> Unit): Uri {
        val conn = URL(media.url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            conn.instanceFollowRedirects = true
            conn.setRequestProperty("User-Agent", UA)
            if (conn.responseCode !in 200..299) throw IOException("Tải thất bại (HTTP ${conn.responseCode})")

            val mime = conn.contentType?.substringBefore(';')?.trim()?.lowercase().orEmpty()
            val isImage = when {
                mime.startsWith("image/") -> true
                mime.startsWith("video/") -> false
                else -> media.kind == Kind.IMAGE
            }
            val finalMime = when {
                isImage && mime.startsWith("image/") -> mime
                isImage -> "image/jpeg"
                mime.startsWith("video/") -> mime
                else -> "video/mp4"
            }
            val ext = when (finalMime) {
                "video/mp4" -> "mp4"
                "video/webm" -> "webm"
                "video/quicktime" -> "mov"
                "image/jpeg" -> "jpg"
                "image/png" -> "png"
                "image/webp" -> "webp"
                "image/gif" -> "gif"
                else -> if (isImage) "jpg" else "mp4"
            }

            val collection = if (isImage) {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val folder = (if (isImage) Environment.DIRECTORY_PICTURES else Environment.DIRECTORY_MOVIES) + "/SnapVideo"

            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.$ext")
                put(MediaStore.MediaColumns.MIME_TYPE, finalMime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val resolver = ctx.contentResolver
            val uri = resolver.insert(collection, values) ?: throw IOException("Không tạo được tệp trong Thư viện")

            try {
                val total = conn.contentLengthLong
                var done = 0L
                var lastPct = -2
                onProgress(-1)
                val out = resolver.openOutputStream(uri) ?: throw IOException("Không ghi được tệp")
                conn.inputStream.use { input ->
                    out.use { output ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            output.write(buf, 0, n)
                            done += n
                            val pct = if (total > 0) (done * 100 / total).toInt() else -1
                            if (pct != lastPct) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
                return uri
            } catch (e: Exception) {
                resolver.delete(uri, null, null)
                throw e
            }
        } finally {
            conn.disconnect()
        }
    }
}
