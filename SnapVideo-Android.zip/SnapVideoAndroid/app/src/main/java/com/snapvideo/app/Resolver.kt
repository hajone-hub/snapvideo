package com.snapvideo.app

import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

enum class Kind { VIDEO, IMAGE }

data class Media(val url: String, val kind: Kind)

const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

/**
 * Biến link chia sẻ thành link tải trực tiếp (không logo).
 *  - TikTok / Douyin: dịch vụ tikwm.com (không chính thức, có thể đổi hoặc giới hạn bất cứ lúc nào).
 *  - Các nền tảng khác (và dự phòng cho TikTok): máy chủ tương thích cobalt do bạn tự cấu hình.
 */
object Resolver {

    fun resolve(link: String, cobaltBase: String, cobaltKey: String): List<Media> {
        val host = try {
            URL(link).host.lowercase()
        } catch (e: Exception) {
            throw IOException("Link không hợp lệ")
        }
        val isTikTok = host.endsWith("tiktok.com") || host.endsWith("douyin.com") ||
                host.endsWith("iesdouyin.com")

        if (isTikTok) {
            try {
                return tikwm(link)
            } catch (e: IOException) {
                if (cobaltBase.isBlank()) throw e
            }
        }
        if (cobaltBase.isBlank()) {
            throw IOException("Link này cần máy chủ cobalt. Bấm ⚙ ở cuối màn hình để nhập địa chỉ máy chủ.")
        }
        return cobalt(link, cobaltBase, cobaltKey)
    }

    // ---------- TikTok / Douyin ----------
    private fun tikwm(link: String): List<Media> {
        var lastMsg = "Không lấy được video"
        for (attempt in 0..1) {
            val json = post(
                "https://www.tikwm.com/api/",
                "url=" + URLEncoder.encode(link, "UTF-8") + "&hd=1",
                "application/x-www-form-urlencoded; charset=UTF-8",
                null
            )
            if (json.optInt("code", -1) == 0) {
                val data = json.getJSONObject("data")
                val images = data.optJSONArray("images")
                if (images != null && images.length() > 0) {
                    return List(images.length()) { Media(absUrl(images.getString(it)), Kind.IMAGE) }
                }
                val video = str(data, "hdplay").ifBlank { str(data, "play") }
                if (video.isNotBlank()) return listOf(Media(absUrl(video), Kind.VIDEO))
                lastMsg = "Không tìm thấy link video"
                break
            }
            lastMsg = str(json, "msg").ifBlank { lastMsg }
            // Dịch vụ miễn phí giới hạn ~1 yêu cầu/giây: đợi rồi thử lại một lần.
            if (attempt == 0 && lastMsg.contains("limit", ignoreCase = true)) {
                Thread.sleep(1500)
                continue
            }
            break
        }
        throw IOException(lastMsg)
    }

    // ---------- Máy chủ cobalt (Instagram, Facebook, X, Threads, Pinterest, Bilibili...) ----------
    private fun cobalt(link: String, base: String, key: String): List<Media> {
        val endpoint = base.trim().trimEnd('/') + "/"
        val auth = key.trim().takeIf { it.isNotEmpty() }?.let { "Api-Key $it" }
        val json = post(endpoint, JSONObject().put("url", link).toString(), "application/json", auth)

        return when (json.optString("status")) {
            "tunnel", "redirect" -> listOf(Media(json.getString("url"), Kind.VIDEO))
            "picker" -> {
                val arr = json.getJSONArray("picker")
                List(arr.length()) {
                    val o = arr.getJSONObject(it)
                    Media(o.getString("url"), if (o.optString("type") == "photo") Kind.IMAGE else Kind.VIDEO)
                }
            }
            else -> {
                val code = json.optJSONObject("error")?.optString("code").orEmpty()
                throw IOException("Máy chủ báo lỗi: " + code.ifBlank { "không rõ" })
            }
        }
    }

    // ---------- tiện ích ----------
    private fun str(o: JSONObject, k: String): String = if (o.isNull(k)) "" else o.optString(k)

    private fun absUrl(u: String): String = when {
        u.startsWith("//") -> "https:$u"
        u.startsWith("/") -> "https://www.tikwm.com$u"
        else -> u
    }

    private fun post(url: String, body: String, contentType: String, auth: String?): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", contentType)
            c.setRequestProperty("Accept", "application/json")
            if (auth != null) c.setRequestProperty("Authorization", auth)
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }

            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else c.errorStream
            val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            return try {
                JSONObject(text)
            } catch (e: Exception) {
                throw IOException("Máy chủ trả về dữ liệu lạ (HTTP $code)")
            }
        } finally {
            c.disconnect()
        }
    }
}
