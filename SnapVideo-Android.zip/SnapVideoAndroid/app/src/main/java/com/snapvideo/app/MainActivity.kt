package com.snapvideo.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("snapvideo", MODE_PRIVATE) }

    private lateinit var input: EditText
    private lateinit var btnDownload: Button
    private lateinit var btnOpen: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var lastUri: Uri? = null
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        input = findViewById(R.id.input)
        btnDownload = findViewById(R.id.btnDownload)
        btnOpen = findViewById(R.id.btnOpen)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.btnPaste).setOnClickListener { pasteFromClipboard() }
        btnDownload.setOnClickListener { startDownload() }
        btnOpen.setOnClickListener { openLast() }
        findViewById<TextView>(R.id.btnSettings).setOnClickListener { showSettings() }

        buildPlatformGrid(findViewById(R.id.grid))
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    // Người dùng bấm Chia sẻ -> SnapVideo: nhận link, tải luôn.
    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_SEND && i.type?.startsWith("text/") == true) {
            val link = findLink(i.getStringExtra(Intent.EXTRA_TEXT).orEmpty())
            i.action = null // tránh tải lại khi xoay màn hình
            if (link != null) {
                input.setText(link)
                startDownload()
            } else {
                setStatus("Không thấy link trong nội dung vừa chia sẻ.", true)
            }
        }
    }

    private fun startDownload() {
        if (busy) return
        val link = findLink(input.text.toString())
        if (link == null) {
            setStatus("Hãy dán link video hợp lệ.", true)
            return
        }
        busy = true
        btnOpen.visibility = View.GONE
        btnDownload.isEnabled = false
        progress.visibility = View.VISIBLE
        progress.isIndeterminate = true
        setStatus("Đợi vài giây…", false)

        val base = prefs.getString("cobalt_url", "").orEmpty()
        val key = prefs.getString("cobalt_key", "").orEmpty()

        io.execute {
            try {
                val items = Resolver.resolve(link, base, key)
                val stamp = System.currentTimeMillis()
                var last: Uri? = null
                items.forEachIndexed { idx, media ->
                    val name = "SnapVideo_$stamp" + if (items.size > 1) "_${idx + 1}" else ""
                    last = Downloader.save(this, media, name) { pct ->
                        runOnUiThread { showProgress(idx, items.size, pct) }
                    }
                }
                runOnUiThread { onDone(last, items.size) }
            } catch (e: Exception) {
                runOnUiThread { onFail(e) }
            }
        }
    }

    private fun showProgress(index: Int, count: Int, pct: Int) {
        if (pct < 0) {
            progress.isIndeterminate = true
        } else {
            progress.isIndeterminate = false
            progress.max = 100
            progress.progress = (index * 100 + pct) / count
        }
    }

    private fun onDone(uri: Uri?, count: Int) {
        busy = false
        btnDownload.isEnabled = true
        progress.visibility = View.GONE
        lastUri = uri
        setStatus(
            if (count > 1) "Xong! Đã lưu $count tệp vào Thư viện." else "Xong! Đã lưu vào Thư viện, không logo.",
            false
        )
        if (uri != null) btnOpen.visibility = View.VISIBLE
    }

    private fun onFail(e: Exception) {
        busy = false
        btnDownload.isEnabled = true
        progress.visibility = View.GONE
        setStatus(e.message ?: "Có lỗi, thử lại nhé.", true)
    }

    private fun setStatus(msg: String, error: Boolean) {
        status.text = msg
        status.setTextColor(getColor(if (error) R.color.error else R.color.muted))
    }

    private fun openLast() {
        val u = lastUri ?: return
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW)
                    .setDataAndType(u, contentResolver.getType(u))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, "Hãy mở trong ứng dụng Thư viện.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this).toString()
        } else ""
        if (text.isNotBlank()) input.setText(text)
    }

    private fun findLink(text: String): String? =
        Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')', ']', '"', '\'')

    private fun showSettings() {
        val pad = (20 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }
        val url = EditText(this).apply {
            hint = "https://cobalt.example.com"
            setText(prefs.getString("cobalt_url", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 1
        }
        val key = EditText(this).apply {
            hint = "API key (nếu máy chủ yêu cầu)"
            setText(prefs.getString("cobalt_key", ""))
            maxLines = 1
        }
        box.addView(url)
        box.addView(key)

        AlertDialog.Builder(this)
            .setTitle("Máy chủ cobalt")
            .setMessage("Dùng cho Instagram, Facebook, X, Threads… TikTok không cần.")
            .setView(box)
            .setPositiveButton("Lưu") { _, _ ->
                var u = url.text.toString().trim()
                if (u.isNotEmpty() && !u.startsWith("http")) u = "https://$u"
                prefs.edit().putString("cobalt_url", u).putString("cobalt_key", key.text.toString().trim()).apply()
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    private fun buildPlatformGrid(grid: GridLayout) {
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()
        listOf(
            "Instagram", "TikTok", "Facebook",
            "Threads", "X", "Douyin",
            "Xiaohongshu", "Pinterest", "Bilibili"
        ).forEach { n ->
            val tv = TextView(this).apply {
                text = n
                setTextColor(Color.WHITE)
                textSize = 13f
                gravity = Gravity.CENTER
                setBackgroundResource(R.drawable.bg_chip)
                setPadding(dp(4), dp(16), dp(4), dp(16))
            }
            val lp = GridLayout.LayoutParams(
                GridLayout.spec(GridLayout.UNDEFINED),
                GridLayout.spec(GridLayout.UNDEFINED, 1f)
            ).apply {
                width = 0
                setMargins(dp(4), dp(4), dp(4), dp(4))
            }
            grid.addView(tv, lp)
        }
    }
}
