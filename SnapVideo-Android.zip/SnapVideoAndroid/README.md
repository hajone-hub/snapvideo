# SnapVideo cho Android

Chia sẻ link TikTok -> chọn **SnapVideo** -> video không logo nằm trong Thư viện (Movies/SnapVideo).

## Build APK
1. Mở thư mục này bằng Android Studio (JDK 17+, Android SDK 34). Đợi Gradle sync (tự tải Gradle 8.7).
2. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
3. File ra ở `app/build/outputs/apk/debug/app-debug.apk`, copy sang điện thoại và cài (cho phép cài từ nguồn không xác định).

## Dùng
- TikTok > Chia sẻ > **SnapVideo**: tự tải. Hoặc mở app, bấm **Dán** rồi **Tải về**.
- TikTok / Douyin chạy ngay (qua tikwm.com, dịch vụ không chính thức, có thể đổi hoặc giới hạn).
- Instagram, Facebook, X, Threads, Pinterest, Bilibili: bấm ⚙ ở cuối màn hình, nhập địa chỉ máy chủ
  tương thích cobalt (tự host) và API key nếu có.

## Code
- `Resolver.kt`   : link chia sẻ -> link tải trực tiếp (tikwm / cobalt). Muốn đổi nguồn chỉ sửa file này.
- `Downloader.kt` : tải và ghi thẳng vào Thư viện bằng MediaStore (Android 10+, không cần quyền bộ nhớ).
- `MainActivity.kt`: giao diện, nhận intent chia sẻ (`ACTION_SEND text/plain`).
